﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RainbowWine.Models.Packers
{
    public class PackerCount
    {
        public int ApprovedUnPacked { get; set; }
        public int Packed { get; set; }
        public int MyProperty { get; set; }
        public int OutForDelivery { get; set; }
        public int Issue { get; set; }
    }
}