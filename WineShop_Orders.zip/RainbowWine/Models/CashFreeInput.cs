﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RainbowWine.Models
{
    public class CashFreeInput
    {
        public string OrderNo { get; set; }
        //public float OrderAmount { get; set; }
        //public string OrderCurrency { get; set; }
    }
}