﻿using System.Web.Mvc;

namespace RainbowWine.Controllers
{
    public class SupplierController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }
    }
}
